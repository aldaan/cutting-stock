#include <iostream>
#include <fstream>
#include "piece.h"

using namespace std;

int main(int argc, char **argv)
{
	Piece stock;
	set<Piece> patterns;

	readInput(stock, patterns);



	return 0;
}

void readInput(Piece& stock, set<Piece>& patterns)
{

	ifstream input("Stock_input_data.txt");
	int x, y, w, h;

	input >> x >> y >> w >> h;
	stock.setCorner(pair<int,int>(x, y));
	stock.setWidth(w);
	stock.setlength(h);

	while (input.good())
	{
		input >> x >> y >> w >> h;
		patterns.insert(Piece(pair<int,int>(x, y), w, h));
	}

	input.close();
}

void writeOutput()
{

}