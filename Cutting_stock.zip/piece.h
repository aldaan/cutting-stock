#ifndef STOCK_H
#define STOCK_H

#include <utility>
#include <set>

class Piece
{
	public:
		Piece();
		Piece(std::pair<int, int> corner, int width, int length);
		std::set<std::pair<int,int> > getCutPoints() const;
		void setCorner(const std::pair<int, int>& corner);
		void setWidth(int width);
		void setLength(int length);
		int getWidth() const;
		int getLength() const;
		const std::pair<int,int>& getCorner() const;
		friend bool operator<(const Piece &lhs, const Piece &rhs);

	private:
		std::pair<int,int> corner;
		int width;
		int length;
		int value;
		int minimum;
		int maximum;
};

#endif /* STOCK_H */
