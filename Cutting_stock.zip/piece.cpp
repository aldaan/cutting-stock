#include "piece.h"

using namespace std;

Piece::Piece()
{

}

Piece::Piece(pair<int, int> corner, int width, int length)
{
	this->corner = corner;
	this->width = width;
	this->length = length;
}

set<pair<int,int> > Piece::getCutPoints() const
{
	set<pair<int,int> > points;

	for (int i = get<0>(corner); i < get<0>(corner) + width; ++i)
	{
		for (int j = get<1>(corner); j < get<0>(corner) + length; ++j)
		{
			points.insert(pair<int,int>(i, j));
		}
	}

	return points;
}

void Piece::setCorner(const pair<int, int>& corner)
{
	this->corner = corner;
}

void Piece::setWidth(int width)
{
	this->width = width;
}

void Piece::setLength(int length)
{
	this->length = length;
}

int Piece::getWidth() const
{
	return width;
}

int Piece::getLength() const
{
	return length;
}

const pair<int,int>& Piece::getCorner() const
{
	return corner;
}

bool operator<(const Piece &lhs, const Piece &rhs)
{
	return lhs.corner < rhs.corner;
}